from bibgrafo.grafo_lista_adjacencia import GrafoListaAdjacencia
from bibgrafo.grafo_exceptions import *


class MeuGrafo(GrafoListaAdjacencia):

    def vertices_nao_adjacentes(self):
        '''
        Provê um conjunto (SET) de vértices não adjacentes no grafo. A lista terá o seguinte formato: [X-Z, X-W, ...]
        Onde X, Z e W são vértices no grafo que não tem uma aresta entre eles.
        :return: Uma lista com os pares de vértices não adjacentes
        '''

        li = set()
        for i in self.N:
            v_adj = list()
            for j in self.A:
                if self.A[j].getV1() == i:
                    v_adj.append(self.A[j].getV2())
                elif self.A[j].getV2() == i:
                    v_adj.append(self.A[j].getV1())

            for k in self.N:
                if i == k:
                    pass
                elif k not in v_adj:
                    vs = (i + '-' + k)
                    li.add(vs)

        return li

    def ha_laco(self):
        '''
        Verifica se existe algum laço no grafo.
        :return: Um valor booleano que indica se existe algum laço.
        '''
        for i in self.A:
            if self.A[i].getV1() == self.A[i].getV2():
                return True

    def grau(self, V=''):
        '''
        Provê o grau do vértice passado como parâmetro
        :param V: O rótulo do vértice a ser analisado
        :return: Um valor inteiro que indica o grau do vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''
        if V not in self.N:
            raise VerticeInvalidoException("O vertice passado é invalido")
        grau = 0
        for i in self.A:
            if self.A[i].getV1() == V:
                grau += 1
            if self.A[i].getV2() == V:
                grau += 1
        return grau

    def ha_paralelas(self):
        '''
        Verifica se há arestas paralelas no grafo
        :return: Um valor booleano que indica se existem arestas paralelas no grafo.
        '''
        arestas = self.A

        for i in arestas:
            a1 = arestas[i]
            for j in arestas:
                a2 = arestas[j]
                if a1 == a2:
                    continue

                if a1.getV1() == a2.getV1():
                    if a1.getV2() == a2.getV2():
                        return True

                if a1.getV1() == a2.getV2():
                    if a1.getV2() == a2.getV1:
                        return True
        return False

    def arestas_sobre_vertice(self, V):
        '''
        Provê uma lista que contém os rótulos das arestas que incidem sobre o vértice passado como parâmetro
        :param V: O vértice a ser analisado
        :return: Uma lista os rótulos das arestas que incidem sobre o vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''
        if V not in self.N:
            raise VerticeInvalidoException("O vértice passado não existe")

        arestas = set()
        for i in self.A:
            if self.A[i].getV1() == V or self.A[i].getV2() == V:
                if i not in arestas:
                    arestas.add(i)

        return arestas

    def arestas_sobre_vertice_list(self, V):
        if V not in self.N:
            raise VerticeInvalidoException("O vértice passado não existe")

        arestas = list()
        for i in self.A:
            if self.A[i].getV1() == V or self.A[i].getV2() == V:
                if i not in arestas:
                    arestas.append(i)

        return arestas

    def eh_completo(self):
        '''
        Verifica se o grafo é completo.
        :return: Um valor booleano que indica se o grafo é completo
        '''
        n_a = len(self.A)
        n_v = len(self.N)

        if n_v * (n_v - 1) / 2 == n_a:
            return True
        else:
            return False

    def dfs_p(self, r):
        visitados = list()
        arvore_dfs = set()
        self.dfs(r, visitados, arvore_dfs)
        return arvore_dfs

    def dfs(self, r, visitados, arvore_dfs):
        for a in self.arestas_sobre_vertice_list(r):
            rotulo = ("{}-{}".format(self.A[a].getV1(), self.A[a].getV2()))
            if self.A[a].getV1() == r:
                if rotulo not in arvore_dfs and self.A[a].getV2() not in visitados:
                    v = self.A[a].getV2()
                    arvore_dfs.add("{}-{}".format(self.A[a].getV1(), self.A[a].getV2()))
                    visitados.append(v)
                    self.dfs(v, visitados, arvore_dfs)
            elif self.A[a].getV2() == r:
                if rotulo not in arvore_dfs and self.A[a].getV1() not in visitados:
                    v = self.A[a].getV1()
                    arvore_dfs.add("{}-{}".format(self.A[a].getV1(), self.A[a].getV2()))
                    visitados.append(v)
                    self.dfs(v, visitados, arvore_dfs)
        return arvore_dfs

    def bfs(self, r):
        visitados = list()
        linha = list()
        fila = list()
        fila.append(r)
        visitados.append(r)
        while fila:
            s = fila.pop(0)
            g = self.arestas_sobre_vertice_list(s)
            for i in g:
                if self.A[i].getV1() != s:
                    a = self.A[i].getV1()
                else:
                    a = self.A[i].getV2()
                if a not in visitados:
                    fila.append(a)
                    linha.append("{}-{}".format(self.A[i].getV1(), self.A[i].getV2()))
                    visitados.append(a)

        return linha


'''
for a in self.arestas_sobre_vertice(r):
    if a not in arvore_dfs and a.getV1() not in vVisitados:
        v = a.getV1()
        arvore_dfs.add(a)
        vVisitados.append(v)
        print(arvore_dfs)
        self.dfs(v)
'''

'''
    def dijkstra_drone(self, vi, vf, carga:int, carga_max:int, pontos_recarga:list()):
        pass
'''
